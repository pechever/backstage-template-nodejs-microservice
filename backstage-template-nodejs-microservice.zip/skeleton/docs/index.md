# ${{ values.name }}

Este microservicio fue generado automáticamente por Backstage.

## Endpoints
- `GET /health`: Verifica que el servicio esté vivo.

## Uso
```bash
docker run -p 3000:3000 <nombre-de-tu-imagen>
```
